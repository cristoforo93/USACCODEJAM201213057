import java.util.Scanner;
import java.util.Random;
public class problema1{
	public static void main(String[] args){
		Random rnd = new Random();
		int num;
		num = rnd.nextInt(100)+1;
		Scanner sc = new Scanner(System.in);
		int ing;
		System.out.println("Adivine el número entre 1 y 100: ");
		ing = sc.nextInt();
		while(ing!=num){
			if(ing==num){
				System.out.println("Número Igual");
				break;
			}else if(ing>num){
				System.out.println("El número ingresado es mayor");
				System.out.println("Vuelva a intentarlo: ");
				ing = sc.nextInt();
			}else if(ing<num){
				System.out.println("El número ingresado es menor");
				System.out.println("Vuelva a intentarlo: ");
				ing = sc.nextInt();
			}else{
				System.out.println("Vuelva a intentarlo");
				ing = sc.nextInt();
			}
		}
		System.out.println("El número ingresado es igual.");
	}
}