public class problema4{
	public static void main(String[] args){
		double v = Double.parseDouble(args[0]);
		double a = Double.parseDouble(args[1]);
		System.out.println("La velocidad inicial en m/s es: "+v+", "+"y el valor del angulo en grados es: "+a);
		Double r = a*((Math.PI)/180);
		Double g=9.8;
		Double t,x;
		t = (2*v*Math.toDegrees(Math.sin(r)))/g;
		x = (Math.pow(v,2)*Math.toDegrees(Math.sin(2*r)))/g;
		System.out.println("La distancia recorrida= "+x+" metros.");
		System.out.println("El tiempo transcurrido= "+t+" segundos.");
	}
}