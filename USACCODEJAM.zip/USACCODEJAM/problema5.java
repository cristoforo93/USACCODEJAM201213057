import java.util.Scanner;
import java.util.Random;
public class problema5{
	public static void main(String[] args){
		Scanner scn = new Scanner(System.in);
		Random rnd = new Random();
		int num1,num2,num3,sum,n;
		num1 = rnd.nextInt(13)+1;
		num2 = rnd.nextInt(13)+1;
		System.out.println("Sus cartas son:");
		System.out.println("[x] [x]");
		System.out.println("¿Desea otra carta?(Si: presione 1; No: presione 2.)");
		n = scn.nextInt();
		if(n==1){
			num3 = rnd.nextInt(13)+1;
			System.out.println("["+num1+"] ["+num2+"] ["+num3+"]");
			sum = num1+num2+num3;
			System.out.println("El total es: "+sum);
			if(sum==21){
				System.out.println("Felicidades!");
			}
		}else if(n==2){
			System.out.println("["+num1+"] ["+num2+"]");
			sum = num1+num2;
			System.out.println("El total es: "+sum);
			if(sum==21){
				System.out.println("Felicidades!");
			}
		}
	}
}